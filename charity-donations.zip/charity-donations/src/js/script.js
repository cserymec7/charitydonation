// This file contains JavaScript functions for handling form submissions, validating input, and navigating between pages.

document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    const donationForm = document.getElementById("donationForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            if (validateLogin(username, password)) {
                // Redirect to payment page
                window.location.href = "payment.html";
            } else {
                alert("Invalid username or password.");
            }
        });
    }

    if (donationForm) {
        donationForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const amount = document.getElementById("amount").value;
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked');

            if (validateDonation(amount, paymentMethod)) {
                alert("Donation confirmed! Thank you for your contribution.");
                // Here you can add further processing like sending data to a server
            } else {
                alert("Please fill in all fields correctly.");
            }
        });
    }

    function validateLogin(username, password) {
        return username.trim() !== "" && password.trim() !== "";
    }

    function validateDonation(amount, paymentMethod) {
        return amount.trim() !== "" && paymentMethod !== null;
    }
});