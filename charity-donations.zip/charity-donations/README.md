# Charity Donations Project

## Overview
The Charity Donations project is a simple web application that allows users to log in and make donations to various charities. The application consists of a login page, a payment details page, and a main entry point that welcomes users.

## Project Structure
```
charity-donations
├── src
│   ├── index.html        # Main entry point of the application
│   ├── login.html        # Login form for user authentication
│   ├── payment.html      # Payment details page for donations
│   ├── css
│   │   └── styles.css    # Styles for the application
│   └── js
│       └── script.js     # JavaScript functions for form handling
└── README.md             # Documentation for the project
```

## Features
- User authentication through a login form.
- Input validation for login credentials.
- Payment details form for entering donation information.
- Responsive design for various screen sizes.

## Usage
1. Open `src/index.html` in a web browser to access the application.
2. Click on the "Login" link to navigate to the login page.
3. Enter your username and password, then submit the form.
4. After successful login, you will be redirected to the payment details page.
5. Fill in the donation amount and select a payment method, then confirm your donation.

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the `charity-donations` directory.
3. Open the `src` folder and start with `index.html`.
4. Ensure you have a web server running if you want to test form submissions.

## Technologies Used
- HTML
- CSS
- JavaScript

## License
This project is open-source and available for anyone to use and modify.